package com.zone.launcher

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile

private val Bg = Color(0xFF111712)
private val Panel = Color(0xFF202820)
private val Green = Color(0xFF91A96B)
private val Muted = Color(0xFFB7C0B0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("zone_launcher", MODE_PRIVATE)

        setContent {
            var folderUri by remember { mutableStateOf(prefs.getString("folder_uri", null)) }
            var status by remember { mutableStateOf("Папка игры не выбрана") }
            var details by remember { mutableStateOf("Выбери каталог с файлами игры.") }
            var showSettings by remember { mutableStateOf(false) }
            var resolution by remember { mutableStateOf(prefs.getString("resolution", "1280×720") ?: "1280×720") }

            val folderPicker = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.OpenDocumentTree()
            ) { uri: Uri? ->
                if (uri != null) {
                    try {
                        contentResolver.takePersistableUriPermission(
                            uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    } catch (_: SecurityException) { }
                    folderUri = uri.toString()
                    prefs.edit().putString("folder_uri", folderUri).apply()
                    status = "Каталог выбран"
                    details = "Нажми «Проверить файлы»."
                }
            }

            MaterialTheme(colorScheme = darkColorScheme(
                primary = Green, background = Bg, surface = Panel, onSurface = Color.White
            )) {
                Column(
                    modifier = Modifier.fillMaxSize().background(Bg)
                        .verticalScroll(rememberScrollState()).padding(22.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text("S.T.A.L.K.E.R.", style = MaterialTheme.typography.headlineMedium, color = Green)
                    Text("ВОЙНА ГРУППИРОВОК", style = MaterialTheme.typography.titleLarge, color = Color.White)
                    Text("ZONE LAUNCHER  •  ANDROID", color = Muted, style = MaterialTheme.typography.labelMedium)
                    HorizontalDivider(color = Green.copy(alpha = 0.45f))

                    Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("СОСТОЯНИЕ", color = Green, style = MaterialTheme.typography.labelLarge)
                            Text(status, color = Color.White, style = MaterialTheme.typography.titleMedium)
                            Text(details, color = Muted, style = MaterialTheme.typography.bodyMedium)
                        }
                    }

                    Button(onClick = { folderPicker.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                        Text("ВЫБРАТЬ ПАПКУ ИГРЫ")
                    }

                    OutlinedButton(onClick = {
                        val raw = folderUri
                        if (raw == null) {
                            status = "Сначала выбери папку"
                            details = "Используй системный выбор каталога."
                        } else {
                            val root = DocumentFile.fromTreeUri(this@MainActivity, Uri.parse(raw))
                            val children = root?.listFiles()?.mapNotNull { it.name } ?: emptyList()
                            val lower = children.map { it.lowercase() }
                            val missing = mutableListOf<String>()
                            if ("fsgame.ltx" !in lower) missing += "fsgame.ltx"
                            if ("gamedata" !in lower) missing += "gamedata"
                            val archives = lower.any {
                                it.endsWith(".db") || Regex(""".*\.db\d+""").matches(it)
                            }
                            if (!archives) missing += "архивы .db*"

                            if (missing.isEmpty()) {
                                status = "Базовые признаки найдены"
                                details = "Предварительная проверка структуры; целостность и совместимость не подтверждены."
                            } else {
                                status = "Не все признаки найдены"
                                details = "Не обнаружено: ${missing.joinToString()}. Возможно, выбран не корень игры или у сборки другая структура."
                            }
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("ПРОВЕРИТЬ ФАЙЛЫ") }

                    Button(onClick = {
                        status = "Движок не подключён"
                        details = "Нужны название/пакет Android-порта и его способ выбора игровых данных. Сейчас кнопка не запускает игру."
                    }, modifier = Modifier.fillMaxWidth()) { Text("ЗАПУСТИТЬ ИГРУ") }

                    OutlinedButton(onClick = { showSettings = !showSettings }, modifier = Modifier.fillMaxWidth()) {
                        Text(if (showSettings) "СКРЫТЬ НАСТРОЙКИ" else "НАСТРОЙКИ")
                    }

                    if (showSettings) {
                        Card(colors = CardDefaults.cardColors(containerColor = Panel), modifier = Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Настройки лаунчера", color = Green, style = MaterialTheme.typography.titleMedium)
                                Text("Предпочитаемое разрешение (пока не меняет параметры движка)", color = Muted)
                                listOf("960×540", "1280×720", "1600×900").forEach { option ->
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        RadioButton(selected = resolution == option, onClick = {
                                            resolution = option
                                            prefs.edit().putString("resolution", option).apply()
                                        })
                                        Text(option, color = Color.White)
                                    }
                                }
                            }
                        }
                    }
                    Text("Сборка 0.1.0 • экспериментальный лаунчер", color = Muted, style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}
