# Zone Launcher — исходный проект

Стартовый Android-проект на Kotlin + Jetpack Compose.

## Возможности прототипа
- выбор каталога через Android Storage Access Framework;
- сохранение доступа к выбранному каталогу;
- предварительная проверка `fsgame.ltx`, `gamedata` и архивов `.db*`;
- настройки лаунчера с сохранением предпочтительного разрешения;
- кнопка запуска с сообщением, пока движок не подключён.

## Сборка APK
1. Установите Android Studio и Android SDK Platform 35.
2. Откройте папку проекта в Android Studio и дождитесь синхронизации Gradle.
3. Выберите Build → Build APK(s).

Путь результата: `app/build/outputs/apk/debug/app-debug.apk`.

В архив не включён Gradle Wrapper JAR; Android Studio может настроить Gradle Wrapper.

## Важно
Это не игровой движок и не готовый запуск Call of Chernobyl. Интеграция зависит от конкретного Android-порта X-Ray, его package ID/API и совместимости с Call of Chernobyl 1.4.22 + Stason174 + EOC. Проверка файлов предварительная.


## Сборка APK в облаке через GitHub Actions

В проект добавлен workflow `.github/workflows/android.yml`. После загрузки **всех файлов и папок проекта** в репозиторий GitHub:
1. Откройте вкладку **Actions** в репозитории.
2. Выберите **Build Android APK**.
3. Нажмите **Run workflow** → **Run workflow**.
4. Дождитесь зелёного статуса сборки, откройте завершённый запуск и скачайте artifact **ZoneLauncher-debug-apk**.
5. Распакуйте скачанный ZIP и установите `app-debug.apk` на телефон.

Workflow собирает только APK-прототип лаунчера. Он не включает игровой движок X-Ray и не запускает саму игру.
